
-- =================================================================================================
--   IP_SPW_BANK_M definition                                                             2018/07/03
-- =================================================================================================

library IEEE;
use IEEE.NUMERIC_STD.all;
use IEEE.STD_LOGIC_1164.all;
use IEEE.STD_LOGIC_arith.ALL;

library NX;
use NX.nxPackage.all;

entity IP_SPW_BANK_M is
generic (
    dataSize  : integer range 4 to 10 := 10;     -- data size can be 4, 6, 8 or 10 bits
    bank      : string  := "IOB12";              -- IO bank name
    reference : string  := "floating"            -- termination reference, can be floating or VT
);
port (
    DO1    : out std_logic;                                         -- SPW1 D out
    SO1    : out std_logic;                                         -- SPW1 S out
    DI1    : in  std_logic := '0';                                  -- SPW1 D in
    SI1    : in  std_logic := '0';                                  -- SPW1 S in

    RXRST1 : in  std_logic := '0';                                  -- SPW1 RX reset
    RXO1   : out std_logic_vector(19 downto 0);                     -- SPW1 RX data out (2x10 bits)
    RXSCK1 : out std_logic;                                         -- SPW1 RX slow clock

    TXRST1 : in  std_logic := '0';                                  -- SPW1 TX reset
    TXI1   : in  std_logic_vector(9 downto 0) := (others => '0');   -- SPW1 TX data in (10 bits)
    TXFCK1 : in  std_logic := '0';                                  -- SPW1 TX fast clock
    TXSCK1 : out std_logic;                                         -- SPW1 TX slow clock

    DO2    : out std_logic;                                         -- SPW2 D out
    SO2    : out std_logic;                                         -- SPW2 S out
    DI2    : in  std_logic := '0';                                  -- SPW2 D in
    SI2    : in  std_logic := '0';                                  -- SPW2 S in

    RXRST2 : in  std_logic := '0';                                  -- SPW2 RX reset
    RXO2   : out std_logic_vector(19 downto 0);                     -- SPW2 RX data out (2x10 bits)
    RXSCK2 : out std_logic;                                         -- SPW2 RX slow clock

    TXRST2 : in  std_logic := '0';                                  -- SPW2 TX reset
    TXI2   : in  std_logic_vector(9 downto 0) := (others => '0');   -- SPW2 TX data in (10 bits)
    TXFCK2 : in  std_logic := '0';                                  -- SPW2 TX fast clock
    TXSCK2 : out std_logic                                          -- SPW2 TX slow clock
);
end IP_SPW_BANK_M;

----------------------------------------------------------------------------------------------------
-- IP_SPW_BANK_M#{{{#
----------------------------------------------------------------------------------------------------
architecture NX_RTL of IP_SPW_BANK_M is

--SPW1 signals#{{{#
signal do1_c: std_logic;
signal do1_i: std_logic;
signal so1_c: std_logic;
signal so1_i: std_logic;
signal di1_c: std_logic;
signal di1_i: std_logic;
signal di1_o: std_logic;
signal si1_c: std_logic;
signal si1_i: std_logic;
signal si1_o: std_logic;
signal RXEN1: std_logic;
signal TXEN1: std_logic;

signal do1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal do1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
--#}}}#

--SPW2 signals#{{{#
signal do2_c: std_logic;
signal do2_i: std_logic;
signal so2_c: std_logic;
signal so2_i: std_logic;
signal di2_c: std_logic;
signal di2_i: std_logic;
signal di2_o: std_logic;
signal si2_c: std_logic;
signal si2_i: std_logic;
signal si2_o: std_logic;
signal RXEN2: std_logic;
signal TXEN2: std_logic;

signal fake_RXCK2_o: std_logic;
signal fake_RXCK2_c: std_logic;
signal fake_RXCK2_i: std_logic;

signal do2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal do2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal fake_RXCK2_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
--#}}}#

--attributes#{{{#
attribute syn_noprune : boolean;
attribute syn_noprune of iob_do1 : label is true;
attribute syn_noprune of iob_so1 : label is true;
attribute syn_noprune of iob_di1 : label is true;
attribute syn_noprune of iob_si1 : label is true;

attribute syn_noprune of iod_do1_p : label is true;
attribute syn_noprune of iod_do1_n : label is true;
attribute syn_noprune of iod_so1_p : label is true;
attribute syn_noprune of iod_so1_n : label is true;
attribute syn_noprune of iod_di1_p : label is true;
attribute syn_noprune of iod_di1_n : label is true;
attribute syn_noprune of iod_si1_p : label is true;
attribute syn_noprune of iod_si1_n : label is true;

attribute syn_noprune of iob_do2 : label is true;
attribute syn_noprune of iob_so2 : label is true;
attribute syn_noprune of iob_di2 : label is true;
attribute syn_noprune of iob_si2 : label is true;
attribute syn_noprune of iob_fake_RXCK2 : label is true;

attribute syn_noprune of iod_do2_p : label is true;
attribute syn_noprune of iod_do2_n : label is true;
attribute syn_noprune of iod_so2_p : label is true;
attribute syn_noprune of iod_so2_n : label is true;
attribute syn_noprune of iod_di2_p : label is true;
attribute syn_noprune of iod_di2_n : label is true;
attribute syn_noprune of iod_si2_p : label is true;
attribute syn_noprune of iod_si2_n : label is true;
attribute syn_noprune of iod_fake_RXCK2 : label is true;

attribute syn_preserve : boolean;
attribute syn_preserve of DO1 : signal is true;
attribute syn_preserve of SO1 : signal is true;

attribute syn_preserve of DO2 : signal is true;
attribute syn_preserve of SO2 : signal is true;
--#}}}#

type switch_pattern is array(integer range 4 to 10) of bit_vector(0 to 15);
constant switch : switch_pattern := (
				      4  => b"1100000000000000"
				    , 5  => b"0000000000000000"
				    , 6  => b"1110000000000000"
				    , 7  => b"0000000000000000"
				    , 8  => b"1111000000000000"
				    , 9  => b"0000000000000000"
				    , 10 => b"1111100000000000"
				    );
constant pattern : bit_vector(0 to 15) := switch(dataSize);

type DIV is array (4 to 10) of bit_vector(3 downto 0);
constant TXDIV : DIV := (
			  4  => b"0011"
			, 5  => b"0000"
			, 6  => b"0101"
			, 7  => b"0000"
			, 8  => b"0111"
			, 9  => b"0000"
			, 10 => b"1001"
			);
constant RXDIV : DIV := (
			  4  => b"0001"
			, 5  => b"0000"
			, 6  => b"0010"
			, 7  => b"0000"
			, 8  => b"0011" -- b"0001" 'fast' mode
			, 9  => b"0000"
			, 10 => b"0100"
			);

signal SYNC1 : std_logic;
signal SYNC2 : std_logic;

begin

--SPW1 components#{{{#
RXEN1 <= NOT(RXRST1);
TXEN1 <= NOT(TXRST1);

iob_do1 : NX_IOB_O
    generic map (
        location     => bank & "_D01P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => do1_i
      , C  => do1_c
      , IO => DO1
    );

iob_so1 : NX_IOB_O
    generic map (
        location     => bank & "_D02P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => so1_i
      , C  => so1_c
      , IO => SO1
    );

iob_di1 : NX_IOB_I
    generic map (
        location             => bank & "_D03P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => di1_c
      , IO => DI1
      , O  => di1_o
    );

iob_si1 : NX_IOB_I
    generic map (
        location             => bank & "_D04P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => si1_c
      , IO => SI1
      , O  => si1_o
    );

iod_do1_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D01P"
      , symbol     => "DSO"
    )
    port map (
        CO   => do1_c
      , EO   => do1_i
      , EI1  => TXI1(0)
      , EI2  => TXI1(1)
      , EI3  => TXI1(2)
      , EI4  => TXI1(3)
      , EI5  => TXI1(4)
      , ER   => TXRST1
      , LINK => do1_p_link
    );

iod_do1_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D01N"
      , chained    => '1'
      , symbol     => "DSOC"
    )
    port map (
        EI1  => TXI1(5)
      , EI2  => TXI1(6)
      , EI3  => TXI1(7)
      , EI4  => TXI1(8)
      , EI5  => TXI1(9)
      , ER   => TXRST1
      , LINK => do1_n_link
    );

iod_so1_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D02P"
      , symbol     => "DSO"
    )
    port map (
        CO   => so1_c
      , EO   => so1_i
      , EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , ER   => TXRST1
      , LINK => so1_p_link
    );

iod_so1_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"1000" -- TEST
      , cpath_mode => b"0001" -- OUTPUT
      , variant    => "ng_medium" -- use RO4 to generate RXSCK1
      , location   => bank & "_D02N"
      , chained    => '1'
      , symbol     => "SOTC"
    )
    port map (
        EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , RO4  => RXSCK1
      , ER   => TXRST1
      , LINK => so1_n_link
    );

iod_di1_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D03P"
      , symbol     => "DSI"
    )
    port map (
        CO   => di1_c
      , EO   => di1_i
      , RI   => di1_o
      , RO1  => RXO1(19)
      , RO2  => RXO1(17)
      , RO3  => RXO1(15)
      , RO4  => RXO1(13)
      , RO5  => RXO1(11)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => di1_p_link
    );

iod_di1_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D03N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO1(9)
      , RO2  => RXO1(7)
      , RO3  => RXO1(5)
      , RO4  => RXO1(3)
      , RO5  => RXO1(1)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => di1_n_link
    );

iod_si1_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D04P"
      , symbol     => "DSI"
    )
    port map (
        CO   => si1_c
      , EO   => si1_i
      , RI   => si1_o
      , RO1  => RXO1(18)
      , RO2  => RXO1(16)
      , RO3  => RXO1(14)
      , RO4  => RXO1(12)
      , RO5  => RXO1(10)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => si1_p_link
    );

iod_si1_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D04N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO1(8)
      , RO2  => RXO1(6)
      , RO3  => RXO1(4)
      , RO4  => RXO1(2)
      , RO5  => RXO1(0)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => si1_n_link
    );

wfg_txck1: NX_WFG
    generic map (
        mode        => '1'
      , pattern_end => dataSize - 1
      , pattern     => pattern
    )
    port map (
        ZI  => TXFCK1
      , ZO  => TXSCK1
      , SI  => SYNC1
      , SO  => SYNC1
    );
--#}}}#

--SPW2 components#{{{#
RXEN2 <= NOT(RXRST2);
TXEN2 <= NOT(TXRST2);

iob_do2 : NX_IOB_O
    generic map (
        location     => bank & "_D12P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => do2_i
      , C  => do2_c
      , IO => DO2
    );

iob_so2 : NX_IOB_O
    generic map (
        location     => bank & "_D13P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
          I  => so2_i
        , C  => so2_c
        , IO => SO2
    );

iob_di2 : NX_IOB_I
    generic map (
        location             => bank & "_D14P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
          C  => di2_c
        , IO => DI2
        , O  => di2_o
    );

iob_si2 : NX_IOB_I
    generic map (
        location             => bank & "_D15P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => si2_c
      , IO => SI2
      , O  => si2_o
    );

iob_fake_RXCK2 : NX_IOB_I
    generic map (
        location => bank & "_D10N"
      , standard => "LVCMOS"
      , drive    => "2mA"
      , locked   => '1'
    )
    port map (
        O => fake_RXCK2_o
      , C => fake_RXCK2_c
    );

iod_fake_RXCK2 : NX_IOM_DRIVER_M
    generic map (
        epath_mode => b"0000" -- CST_0
      , rpath_mode => b"1000" -- TEST
      , cpath_mode => b"0000" -- OUTPUT
      , variant    => "ng_medium" --use RO4 to generate RXSCK2
      , location   => bank & "_D10N"
      , symbol     => "FAKE"
    )
    port map (
        RI   => fake_RXCK2_o
      , RO4  => RXSCK2
      , EO   => fake_RXCK2_i
      , CO   => fake_RXCK2_c
      , LINK => fake_RXCK2_link
    );

iod_do2_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D12P"
      , symbol     => "DSO"
    )
    port map (
        CO   => do2_c
      , EO   => do2_i
      , EI1  => TXI2(0)
      , EI2  => TXI2(1)
      , EI3  => TXI2(2)
      , EI4  => TXI2(3)
      , EI5  => TXI2(4)
      , ER   => TXRST2
      , LINK => do2_p_link
    );

iod_do2_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D12N"
      , chained    => '1'
      , symbol     => "DSOC"
    )
    port map (
        EI1  => TXI2(5)
      , EI2  => TXI2(6)
      , EI3  => TXI2(7)
      , EI4  => TXI2(8)
      , EI5  => TXI2(9)
      , ER   => TXRST2
      , LINK => do2_n_link
    );

iod_so2_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D13P"
      , symbol     => "DSO"
    )
    port map (
        CO   => so2_c
      , EO   => so2_i
      , EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , ER   => TXRST2
      , LINK => so2_p_link
    );

iod_so2_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D13N"
      , chained    => '1'
      , symbol     => "DSOC"
    )
    port map (
        EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , ER   => TXRST2
      , LINK => so2_n_link
    );

iod_di2_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D14P"
      , symbol     => "DSI"
    )
    port map (
        CO   => di2_c
      , EO   => di2_i
      , RI   => di2_o
      , RO1  => RXO2(19)
      , RO2  => RXO2(17)
      , RO3  => RXO2(15)
      , RO4  => RXO2(13)
      , RO5  => RXO2(11)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => di2_p_link
    );

iod_di2_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D14N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO2(9)
      , RO2  => RXO2(7)
      , RO3  => RXO2(5)
      , RO4  => RXO2(3)
      , RO5  => RXO2(1)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => di2_n_link
    );

iod_si2_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D15P"
      , symbol     => "DSI"
    )
    port map (
        CO   => si2_c
      , EO   => si2_i
      , RI   => si2_o
      , RO1  => RXO2(18)
      , RO2  => RXO2(16)
      , RO3  => RXO2(14)
      , RO4  => RXO2(12)
      , RO5  => RXO2(10)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => si2_p_link
    );

iod_si2_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D15N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO2(8)
      , RO2  => RXO2(6)
      , RO3  => RXO2(4)
      , RO4  => RXO2(2)
      , RO5  => RXO2(0)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => si2_n_link
    );

wfg_txck2: NX_WFG
    generic map (
        mode        => '1'
      , pattern_end => dataSize - 1
      , pattern     => pattern
    )
    port map (
        ZI  => TXFCK2
      , ZO  => TXSCK2
      , SI  => SYNC2
      , SO  => SYNC2
    );
--#}}}#

--IOM_CONTROL#{{{#
ioc : NX_IOM_CONTROL
    generic map (
        mode_side1   => 2
      , mode_side2   => 2
      , mode_io_cal  => '0'
      , inv_di_fclk1 => '0'
      , inv_di_fclk2 => '0'
      , latency1     => '0'
      , latency2     => '0'
      , sel_clk_out1 => '0' -- 00: from pad, 01 : from cdc, 10 & 11 : useless
      , sel_clk_out2 => '0'
      , sel_clkw_rx1 => "10" -- 00, 01 : autoselect from run, 10: spw, 11: dqs
      , sel_clkr_rx1 => '1'   -- 0: autoselect from run, 1: cdc
      , sel_clkw_rx2 => "10"
      , sel_clkr_rx2 => '1'
      , div_tx1      => TXDIV(dataSize)
      , div_rx1      => RXDIV(dataSize)
      , div_tx2      => TXDIV(dataSize)
      , div_rx2      => RXDIV(dataSize)
      , location     => bank
    )
    port map (
        LINK1  => do1_p_link
      , LINK2  => do1_n_link
      , LINK3  => so1_p_link
      , LINK4  => so1_n_link
      , LINK5  => di1_p_link
      , LINK6  => di1_n_link
      , LINK7  => si1_p_link
      , LINK8  => si1_n_link
      , LINK20 => fake_RXCK2_link
      , LINK23 => do2_p_link
      , LINK24 => do2_n_link
      , LINK25 => so2_p_link
      , LINK26 => so2_n_link
      , LINK27 => di2_p_link
      , LINK28 => di2_n_link
      , LINK29 => si2_p_link
      , LINK30 => si2_n_link

      , RRCK1  => RXSCK1	-- RCK

      , RTCK1  => TXFCK1	-- ECK
      , WTCK1  => TXSCK1

      , C1TW   => TXEN1
      , C1RW1  => RXEN1
      , C1RW2  => RXEN1
      , C1RW3  => RXEN1
      , C1RNE  => RXEN1

      , RRCK2  => RXSCK2	-- RCK

      , RTCK2  => TXFCK2	-- ECK
      , WTCK2  => TXSCK2

      , C2TW   => TXEN2
      , C2RW1  => RXEN2
      , C2RW2  => RXEN2
      , C2RW3  => RXEN2
      , C2RNE  => RXEN2
  );
--#}}}#

end NX_RTL;
--#}}}#


-- =================================================================================================
--   IP_SPW_BANK_L_L definition
-- =================================================================================================

library IEEE;
use IEEE.NUMERIC_STD.all;
use IEEE.STD_LOGIC_1164.all;
use IEEE.STD_LOGIC_arith.ALL;

library NX;
use NX.nxPackage.all;

entity IP_SPW_BANK_L is
generic (
    dataSize  : integer range 4 to 10 := 10;     -- data size can be 4, 6, 8 or 10 bits
    bank      : string  := "IOB23";              -- IO bank name
    reference : string  := "floating"            -- termination reference, can be floating or VT
);
port (
    DO1    : out std_logic;                                         -- SPW1 D out
    SO1    : out std_logic;                                         -- SPW1 S out
    DI1    : in  std_logic := '0';                                  -- SPW1 D in
    SI1    : in  std_logic := '0';                                  -- SPW1 S in

    RXRST1 : in  std_logic := '0';                                  -- SPW1 RX reset
    RXO1   : out std_logic_vector(19 downto 0);                     -- SPW1 RX data out (2x10 bits)
    RXSCK1 : out std_logic;                                         -- SPW1 RX slow clock

    TXRST1 : in  std_logic := '0';                                  -- SPW1 TX reset
    TXI1   : in  std_logic_vector(9 downto 0) := (others => '0');   -- SPW1 TX data in (10 bits)
    TXFCK1 : in  std_logic := '0';                                  -- SPW1 TX fast clock
    TXSCK1 : out std_logic;                                         -- SPW1 TX slow clock

    DO2    : out std_logic;                                         -- SPW2 D out
    SO2    : out std_logic;                                         -- SPW2 S out
    DI2    : in  std_logic := '0';                                  -- SPW2 D in
    SI2    : in  std_logic := '0';                                  -- SPW2 S in

    RXRST2 : in  std_logic := '0';                                  -- SPW2 RX reset
    RXO2   : out std_logic_vector(19 downto 0);                     -- SPW2 RX data out (2x10 bits)
    RXSCK2 : out std_logic;                                         -- SPW2 RX slow clock

    TXRST2 : in  std_logic := '0';                                  -- SPW2 TX reset
    TXI2   : in  std_logic_vector(9 downto 0) := (others => '0');   -- SPW2 TX data in (10 bits)
    TXFCK2 : in  std_logic := '0';                                  -- SPW2 TX fast clock
    TXSCK2 : out std_logic                                          -- SPW2 TX slow clock
);
end IP_SPW_BANK_L;

----------------------------------------------------------------------------------------------------
-- IP_SPW_BANK_L#{{{#
----------------------------------------------------------------------------------------------------
architecture NX_RTL of IP_SPW_BANK_L is

--SPW1 signals#{{{#
signal do1_c: std_logic;
signal do1_i: std_logic;
signal so1_c: std_logic;
signal so1_i: std_logic;
signal di1_c: std_logic;
signal di1_i: std_logic;
signal di1_o: std_logic;
signal si1_c: std_logic;
signal si1_i: std_logic;
signal si1_o: std_logic;
signal RXEN1: std_logic;
signal TXEN1: std_logic;

signal do1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal do1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si1_n_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
--#}}}#

--SPW2 signals#{{{#
signal do2_c: std_logic;
signal do2_i: std_logic;
signal so2_c: std_logic;
signal so2_i: std_logic;
signal di2_c: std_logic;
signal di2_i: std_logic;
signal di2_o: std_logic;
signal si2_c: std_logic;
signal si2_i: std_logic;
signal si2_o: std_logic;
signal RXEN2: std_logic;
signal TXEN2: std_logic;

signal do2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal do2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si2_n_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
--#}}}#

--attributes#{{{#
attribute syn_noprune : boolean;
attribute syn_noprune of iob_do1 : label is true;
attribute syn_noprune of iob_so1 : label is true;
attribute syn_noprune of iob_di1 : label is true;
attribute syn_noprune of iob_si1 : label is true;

attribute syn_noprune of iod_do1_p : label is true;
attribute syn_noprune of iod_do1_n : label is true;
attribute syn_noprune of iod_so1_p : label is true;
attribute syn_noprune of iod_so1_n : label is true;
attribute syn_noprune of iod_di1_p : label is true;
attribute syn_noprune of iod_di1_n : label is true;
attribute syn_noprune of iod_si1_p : label is true;
attribute syn_noprune of iod_si1_n : label is true;

attribute syn_noprune of iob_do2 : label is true;
attribute syn_noprune of iob_so2 : label is true;
attribute syn_noprune of iob_di2 : label is true;
attribute syn_noprune of iob_si2 : label is true;

attribute syn_noprune of iod_do2_p : label is true;
attribute syn_noprune of iod_do2_n : label is true;
attribute syn_noprune of iod_so2_p : label is true;
attribute syn_noprune of iod_so2_n : label is true;
attribute syn_noprune of iod_di2_p : label is true;
attribute syn_noprune of iod_di2_n : label is true;
attribute syn_noprune of iod_si2_p : label is true;
attribute syn_noprune of iod_si2_n : label is true;

attribute syn_preserve : boolean;
attribute syn_preserve of DO1 : signal is true;
attribute syn_preserve of SO1 : signal is true;

attribute syn_preserve of DO2 : signal is true;
attribute syn_preserve of SO2 : signal is true;
--#}}}#

type switch_pattern is array(integer range 4 to 10) of bit_vector(0 to 15);
constant switch : switch_pattern := (
				      4  => b"1100000000000000"
				    , 5  => b"0000000000000000"
				    , 6  => b"1110000000000000"
				    , 7  => b"0000000000000000"
				    , 8  => b"1111000000000000"
				    , 9  => b"0000000000000000"
				    , 10 => b"1111100000000000"
				    );
constant pattern : bit_vector(0 to 15) := switch(dataSize);

type DIV is array (4 to 10) of bit_vector(3 downto 0);
constant TXDIV : DIV := (
			  4  => b"0011"
			, 5  => b"0000"
			, 6  => b"0101"
			, 7  => b"0000"
			, 8  => b"0111"
			, 9  => b"0000"
			, 10 => b"1001"
			);
constant RXDIV : DIV := (
			  4  => b"0001"
			, 5  => b"0000"
			, 6  => b"0010"
			, 7  => b"0000"
			, 8  => b"0011" -- b"0001" 'fast' mode
			, 9  => b"0000"
			, 10 => b"0100"
			);

signal SYNC1 : std_logic;
signal SYNC2 : std_logic;

begin

--SPW1 components#{{{#
RXEN1 <= NOT(RXRST1);
TXEN1 <= NOT(TXRST1);

iob_do1 : NX_IOB_O
    generic map (
        location     => bank & "_D01P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => do1_i
      , C  => do1_c
      , IO => DO1
    );

iob_so1 : NX_IOB_O
    generic map (
        location     => bank & "_D02P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => so1_i
      , C  => so1_c
      , IO => SO1
    );

iob_di1 : NX_IOB_I
    generic map (
        location             => bank & "_D03P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => di1_c
      , IO => DI1
      , O  => di1_o
    );

iob_si1 : NX_IOB_I
    generic map (
        location             => bank & "_D04P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => si1_c
      , IO => SI1
      , O  => si1_o
    );

iod_do1_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D01P"
      , symbol     => "DSO"
    )
    port map (
        CO   => do1_c
      , EO   => do1_i
      , EI1  => TXI1(0)
      , EI2  => TXI1(1)
      , EI3  => TXI1(2)
      , EI4  => TXI1(3)
      , EI5  => TXI1(4)
      , ER   => TXRST1
      , LINK => do1_p_link
    );

iod_do1_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D01N"
      , chained    => '1'
      , symbol     => "DSOC"
    )
    port map (
        EI1  => TXI1(5)
      , EI2  => TXI1(6)
      , EI3  => TXI1(7)
      , EI4  => TXI1(8)
      , EI5  => TXI1(9)
      , ER   => TXRST1
      , LINK => do1_n_link
    );

iod_so1_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D02P"
      , symbol     => "DSO"
    )
    port map (
        CO   => so1_c
      , EO   => so1_i
      , EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , ER   => TXRST1
      , LINK => so1_p_link
    );

iod_so1_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"1000" -- TEST
      , cpath_mode => b"0001" -- OUTPUT
      , variant    => "ng_large" -- use RO5 to generate RXSCK1
      , location   => bank & "_D02N"
      , chained    => '1'
      , symbol     => "SOTC"
    )
    port map (
        EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , RO5  => RXSCK1
      , ER   => TXRST1
      , LINK => so1_n_link
    );

iod_di1_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D03P"
      , symbol     => "DSI"
    )
    port map (
        CO   => di1_c
      , EO   => di1_i
      , RI   => di1_o
      , RO1  => RXO1(19)
      , RO2  => RXO1(17)
      , RO3  => RXO1(15)
      , RO4  => RXO1(13)
      , RO5  => RXO1(11)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => di1_p_link
    );

iod_di1_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D03N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO1(9)
      , RO2  => RXO1(7)
      , RO3  => RXO1(5)
      , RO4  => RXO1(3)
      , RO5  => RXO1(1)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => di1_n_link
    );

iod_si1_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D04P"
      , symbol     => "DSI"
    )
    port map (
        CO   => si1_c
      , EO   => si1_i
      , RI   => si1_o
      , RO1  => RXO1(18)
      , RO2  => RXO1(16)
      , RO3  => RXO1(14)
      , RO4  => RXO1(12)
      , RO5  => RXO1(10)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => si1_p_link
    );

iod_si1_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D04N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO1(8)
      , RO2  => RXO1(6)
      , RO3  => RXO1(4)
      , RO4  => RXO1(2)
      , RO5  => RXO1(0)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => si1_n_link
    );

wfg_txck1: NX_WFG_L
    generic map (
        mode        => '1'
      , pattern_end => dataSize - 1
      , pattern     => pattern
    )
    port map (
        ZI  => TXFCK1
      , ZO  => TXSCK1
      , SI  => SYNC1
      , SO  => SYNC1
    );
--#}}}#

--SPW2 components#{{{#
RXEN2 <= NOT(RXRST2);
TXEN2 <= NOT(TXRST2);

iob_do2 : NX_IOB_O
    generic map (
        location     => bank & "_D14P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => do2_i
      , C  => do2_c
      , IO => DO2
    );

iob_so2 : NX_IOB_O
    generic map (
        location     => bank & "_D15P"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
          I  => so2_i
        , C  => so2_c
        , IO => SO2
    );

iob_di2 : NX_IOB_I
    generic map (
        location             => bank & "_D16P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
          C  => di2_c
        , IO => DI2
        , O  => di2_o
    );

iob_si2 : NX_IOB_I
    generic map (
        location             => bank & "_D17P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => si2_c
      , IO => SI2
      , O  => si2_o
    );

iod_do2_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D14P"
      , symbol     => "DSO"
    )
    port map (
        CO   => do2_c
      , EO   => do2_i
      , EI1  => TXI2(0)
      , EI2  => TXI2(1)
      , EI3  => TXI2(2)
      , EI4  => TXI2(3)
      , EI5  => TXI2(4)
      , ER   => TXRST2
      , LINK => do2_p_link
    );

iod_do2_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D14N"
      , chained    => '1'
      , symbol     => "DSOC"
    )
    port map (
        EI1  => TXI2(5)
      , EI2  => TXI2(6)
      , EI3  => TXI2(7)
      , EI4  => TXI2(8)
      , EI5  => TXI2(9)
      , ER   => TXRST2
      , LINK => do2_n_link
    );

iod_so2_p : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , location   => bank & "_D15P"
      , symbol     => "DSO"
    )
    port map (
        CO   => so2_c
      , EO   => so2_i
      , EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , ER   => TXRST2
      , LINK => so2_p_link
    );

iod_so2_n : NX_IOM_DRIVER_M
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"1000" -- TEST
      , cpath_mode => b"0001" -- OUTPUT
      , variant    => "ng_large" -- use RO5 to generate RXSCK2
      , location   => bank & "_D15N"
      , chained    => '1'
      , symbol     => "SOTC"
    )
    port map (
        EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , RO5  => RXSCK2
      , ER   => TXRST2
      , LINK => so2_n_link
    );

iod_di2_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D16P"
      , symbol     => "DSI"
    )
    port map (
        CO   => di2_c
      , EO   => di2_i
      , RI   => di2_o
      , RO1  => RXO2(19)
      , RO2  => RXO2(17)
      , RO3  => RXO2(15)
      , RO4  => RXO2(13)
      , RO5  => RXO2(11)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => di2_p_link
    );

iod_di2_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D16N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO2(9)
      , RO2  => RXO2(7)
      , RO3  => RXO2(5)
      , RO4  => RXO2(3)
      , RO5  => RXO2(1)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => di2_n_link
    );

iod_si2_p : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D17P"
      , symbol     => "DSI"
    )
    port map (
        CO   => si2_c
      , EO   => si2_i
      , RI   => si2_o
      , RO1  => RXO2(18)
      , RO2  => RXO2(16)
      , RO3  => RXO2(14)
      , RO4  => RXO2(12)
      , RO5  => RXO2(10)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => si2_p_link
    );

iod_si2_n : NX_IOM_DRIVER_M
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , location   => bank & "_D17N"
      , chained    => '1'
      , symbol     => "DSIC"
    )
    port map (
        RO1  => RXO2(8)
      , RO2  => RXO2(6)
      , RO3  => RXO2(4)
      , RO4  => RXO2(2)
      , RO5  => RXO2(0)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => si2_n_link
    );

wfg_txck2: NX_WFG_L
    generic map (
        mode        => '1'
      , pattern_end => dataSize - 1
      , pattern     => pattern
    )
    port map (
        ZI  => TXFCK2
      , ZO  => TXSCK2
      , SI  => SYNC2
      , SO  => SYNC2
    );
--#}}}#

--IOM_CONTROL#{{{#
ioc : NX_IOM_CONTROL_L
    generic map (
        mode_side1   => 2
      , mode_side2   => 2
      , mode_io_cal  => '0'
      , inv_di_fclk1 => '0'
      , inv_di_fclk2 => '0'
      , latency1     => '0'
      , latency2     => '0'
      , sel_clk_out1 => '0' -- 00: from pad, 01 : from cdc, 10 & 11 : useless
      , sel_clk_out2 => '0'
      , sel_clkw_rx1 => "10" -- 00, 01 : autoselect from run, 10: spw, 11: dqs
      , sel_clkr_rx1 => '1'   -- 0: autoselect from run, 1: cdc
      , sel_clkw_rx2 => "10"
      , sel_clkr_rx2 => '1'
      , div_tx1      => TXDIV(dataSize)
      , div_rx1      => RXDIV(dataSize)
      , div_tx2      => TXDIV(dataSize)
      , div_rx2      => RXDIV(dataSize)
      , location     => bank
    )
    port map (
        LINK1  => do1_p_link
      , LINK2  => do1_n_link
      , LINK3  => so1_p_link
      , LINK4  => so1_n_link
      , LINK5  => di1_p_link
      , LINK6  => di1_n_link
      , LINK7  => si1_p_link
      , LINK8  => si1_n_link
      , LINK27 => do2_p_link
      , LINK28 => do2_n_link
      , LINK29 => so2_p_link
      , LINK30 => so2_n_link
      , LINK31 => di2_p_link
      , LINK32 => di2_n_link
      , LINK33 => si2_p_link
      , LINK34 => si2_n_link

      , RRCK1  => RXSCK1	-- RCK

      , RTCK1  => TXFCK1	-- ECK
      , WTCK1  => TXSCK1

      , C1TW   => TXEN1
      , C1RW1  => RXEN1
      , C1RW2  => RXEN1
      , C1RW3  => RXEN1
      , C1RNE  => RXEN1

      , RRCK2  => RXSCK2	-- RCK

      , RTCK2  => TXFCK2	-- ECK
      , WTCK2  => TXSCK2

      , C2TW   => TXEN2
      , C2RW1  => RXEN2
      , C2RW2  => RXEN2
      , C2RW3  => RXEN2
      , C2RNE  => RXEN2
  );
--#}}}#
end NX_RTL;



-- =================================================================================================
--   IP_SPW_BANK_U definition
-- =================================================================================================

library IEEE;
use IEEE.NUMERIC_STD.all;
use IEEE.STD_LOGIC_1164.all;
use IEEE.STD_LOGIC_arith.ALL;

library NX;
use NX.nxPackage.all;

entity IP_SPW_BANK_U is
generic (
    -- dataSizeTx  : integer range 4 to 8 := 8;        -- data size can be 4, 6, 8
    -- dataSizeRx  : integer range 4 to 8 := 8;        -- data size can be 4, 6, 8
    dataSize    : integer range 4 to 8 := 8;        -- data size can be 4, 6, 8
    bank        : string  := "IOB23";               -- IO bank name
    reference   : string  := "floating"             -- termination reference, can be floating or VT
);
port (
    DO1    : out std_logic;                                         -- SPW1 D out
    SO1    : out std_logic;                                         -- SPW1 S out
    DI1    : in  std_logic := '0';                                  -- SPW1 D in
    SI1    : in  std_logic := '0';                                  -- SPW1 S in

    RXRST1 : in  std_logic := '0';                                  -- SPW1 RX reset
    RXO1   : out std_logic_vector(15 downto 0);                     -- SPW1 RX data out (2x8 bits)
    RXSCK1 : out std_logic;                                         -- SPW1 RX slow clock

    TXRST1 : in  std_logic := '0';                                  -- SPW1 TX reset
    TXI1   : in  std_logic_vector(7 downto 0) := (others => '0');   -- SPW1 TX data in (8 bits)
    TXFCK1 : in  std_logic := '0';                                  -- SPW1 TX fast clock
    TXSCK1 : out std_logic;                                         -- SPW1 TX slow clock

    DO2    : out std_logic;                                         -- SPW2 D out
    SO2    : out std_logic;                                         -- SPW2 S out
    DI2    : in  std_logic := '0';                                  -- SPW2 D in
    SI2    : in  std_logic := '0';                                  -- SPW2 S in

    RXRST2 : in  std_logic := '0';                                  -- SPW2 RX reset
    RXO2   : out std_logic_vector(15 downto 0);                     -- SPW2 RX data out (2x8 bits)
    RXSCK2 : out std_logic;                                         -- SPW2 RX slow clock

    TXRST2 : in  std_logic := '0';                                  -- SPW2 TX reset
    TXI2   : in  std_logic_vector(7 downto 0) := (others => '0');   -- SPW2 TX data in (8 bits)
    TXFCK2 : in  std_logic := '0';                                  -- SPW2 TX fast clock
    TXSCK2 : out std_logic                                          -- SPW2 TX slow clock

   --SER_SCK_FABRIC : out std_logic;
   --SER_FCK_FABRIC : out std_logic;
   --SER_SCK_IOM    : out std_logic;
   --IODSER_ENABLE  : out std_logic;

   --SER_WPTR        : out std_logic;
   --SER_CHAIN_IN    : out std_logic;
   --SER_RPTR        : out std_logic;
   --DES_SCK_IOM     : out std_logic;
   --DES_SCK_FABRIC  : out std_logic;
   --SPW_TX_DO       : out std_logic;
   --TXI1_DO_TEST    : out std_logic
);
end IP_SPW_BANK_U;


-- PROTECT_KEY[NX, MGC]

----------------------------------------------------------------------------------------------------
-- IP_SPW_BANK#{{{#
----------------------------------------------------------------------------------------------------
architecture NX_RTL of IP_SPW_BANK_U is

--SPW1 signals#{{{#
signal do1_c: std_logic;
signal do1_i: std_logic;
signal so1_c: std_logic;
signal so1_i: std_logic;
signal di1_c: std_logic;
signal di1_i: std_logic;
signal di1_o: std_logic;
signal si1_c: std_logic;
signal si1_i: std_logic;
signal si1_o: std_logic;
signal RXEN1: std_logic;
signal TXEN1: std_logic;

signal do1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si1_p_link: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);

signal LINK_SPW0: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal LINK_SPW1: std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
--#}}}#

--SPW2 signals#{{{#
signal do2_c: std_logic;
signal do2_i: std_logic;
signal so2_c: std_logic;
signal so2_i: std_logic;
signal di2_c: std_logic;
signal di2_i: std_logic;
signal di2_o: std_logic;
signal si2_c: std_logic;
signal si2_i: std_logic;
signal si2_o: std_logic;
signal RXEN2: std_logic;
signal TXEN2: std_logic;

signal do2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal so2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal di2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);
signal si2_p_link:      std_logic_vector(IOM_LINK_SIZE - 1 downto 0);

signal TXSCK1_IOM : std_logic;
signal TXSCK2_IOM : std_logic;

--#}}}#

--attributes#{{{#
--attribute syn_noprune : boolean;
--attribute syn_noprune of iob_do1 : label is true;
--attribute syn_noprune of iob_so1 : label is true;
--attribute syn_noprune of iob_di1 : label is true;
--attribute syn_noprune of iob_si1 : label is true;
--
--attribute syn_noprune of iob_do2 : label is true;
--attribute syn_noprune of iob_so2 : label is true;
--attribute syn_noprune of iob_di2 : label is true;
--attribute syn_noprune of iob_si2 : label is true;
--
--attribute syn_preserve : boolean;
--attribute syn_preserve of DO1 : signal is true;
--attribute syn_preserve of SO1 : signal is true;
--
--attribute syn_preserve of DO2 : signal is true;
--attribute syn_preserve of SO2 : signal is true;
--#}}}#

-- => IP_SPW_BANK ne supporte pas config 5 bits a cause de pattern?? Utiliser division / 5 sans pattern 
type switch_pattern is array(integer range 4 to 8) of bit_vector(0 to 15);
constant switch : switch_pattern := (
				      4  => b"1100000000000000"
				    , 5  => b"0000000000000000"
				    , 6  => b"1110000000000000"
				    , 7  => b"0000000000000000"
				    , 8  => b"1111000000000000"
				    );
constant pattern : bit_vector(0 to 15) := switch(dataSize);
-- constant pattern : bit_vector(0 to 15) := switch(dataSizeTx);

type DIV is array (4 to 8) of bit_vector(2 downto 0);
constant TXDIV : DIV := (
			  4  => b"011" -- Div by 4
			, 5  => b"100"
			, 6  => b"101"
			, 7  => b"110"
			, 8  => b"111" -- Div by 8
	);
constant RXDIV : DIV := (
			  4  => b"011" -- Div by 4
			, 5  => b"100"
			, 6  => b"101"
			, 7  => b"110"
			, 8  => b"111" -- Div by 8
			);

signal SYNC1, SYNC1_IOM, SYNC1_RXSCK1, SYNC1_RXSCK1_DIV5 : std_logic;
signal SYNC2, SYNC2_IOM, SYNC2_RXSCK2, SYNC2_RXSCK2_DIV5 : std_logic;
signal CKO1, CKO2 : std_logic;

begin

--SPW1 components#{{{#
RXEN1 <= NOT(RXRST1);
TXEN1 <= NOT(TXRST1);

iob_do1 : NX_IOB_O
    generic map (
        location     => bank & "_D00P"
      -- , standard     => "LVCMOS"
      -- , drive        => "4 mA"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => do1_i
      , C  => do1_c
      , IO => DO1
    );

iob_so1 : NX_IOB_O
    generic map (
        location     => bank & "_D01P"
      -- , standard     => "LVCMOS"
      -- , drive        => "4 mA"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => so1_i
      , C  => so1_c
      , IO => SO1
    );

iob_di1 : NX_IOB_I
    generic map (
        location             => bank & "_D02P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => di1_c
      , IO => DI1
      , O  => di1_o
    );

iob_si1 : NX_IOB_I
    generic map (
        location             => bank & "_D03P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => si1_c
      , IO => SI1
      , O  => si1_o
    );

iod_do1_p : NX_IOM_DRIVER_U
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , chained    => '1'
      , location   => bank & "_D00P"
      , symbol     => "DSO_DO1"
    )
    port map (
        CO   => do1_c
      , EO   => do1_i
      , EI1  => TXI1(0)--txi1_do(0)
      , EI2  => TXI1(1)--txi1_do(1)
      , EI3  => TXI1(2)--txi1_do(2)
      , EI4  => TXI1(3)--txi1_do(3)
      , EI5  => TXI1(4)--txi1_do(4)
      , EI6  => TXI1(5)--txi1_do(5)
      , EI7  => TXI1(6)--txi1_do(6)
      , EI8  => TXI1(7)--txi1_do(7)
      , ER   => TXEN1
      , LINK => do1_p_link
    );

iod_so1_p : NX_IOM_DRIVER_U
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , epath_dynamic => '1'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , chained    => '1'
      , location   => bank & "_D01P"
      , symbol     => "DSO_SO1"
    )
    port map (
        CO   => so1_c
      , EO   => so1_i
      , EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , EI6  => '1'
      , EI7  => '1'
      , EI8  => '1'
      , ER   => TXEN1
      , LINK => so1_p_link
    );

iod_di1_p : NX_IOM_DRIVER_U
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , chained    => '1'
      , location   => bank & "_D02P"
      , symbol     => "DSI_DI1"
    )
    port map (
        CO   => di1_c
      , EO   => di1_i
      , RI   => di1_o
      , RO1  => RXO1(0)--rxi1_di(0) 
      , RO2  => RXO1(2)--rxi1_di(1) 
      , RO3  => RXO1(4)--rxi1_di(2) 
      , RO4  => RXO1(6)--rxi1_di(3) 
      , RO5  => RXO1(8)--rxi1_di(4) 
      , RO6  => RXO1(10)--rxi1_di(5)
      , RO7  => RXO1(12)--rxi1_di(6)
      , RO8  => RXO1(14)--rxi1_di(7)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => di1_p_link
    );

iod_si1_p : NX_IOM_DRIVER_U
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , chained    => '1'
      , location   => bank & "_D03P"
      , symbol     => "DSI_SI1"
    )
    port map (
        CO   => si1_c
      , EO   => si1_i
      , RI   => si1_o
      , RO1  => RXO1(1) --rxi1_si(0)
      , RO2  => RXO1(3) --rxi1_si(1)
      , RO3  => RXO1(5) --rxi1_si(2)
      , RO4  => RXO1(7) --rxi1_si(3)
      , RO5  => RXO1(9) --rxi1_si(4)
      , RO6  => RXO1(11) --rxi1_si(5)
      , RO7  => RXO1(13) --rxi1_si(6)
      , RO8  => RXO1(15) --rxi1_si(7)
      , RR   => RXRST1
      , ER   => RXEN1       -- enable SWRX
      , LINK => si1_p_link
    );

-- slow clock TXSCK1 generation
wfg_txck1: NX_WFG_U
  generic map (
      mode        => 1
    , pattern_end => dataSize - 1
    -- , pattern_end => dataSizeTx - 1
    , pattern     => pattern
  )
  port map (
      ZI  => TXFCK1
    , ZO  => TXSCK1
    , SI  => SYNC1
    , SO  => SYNC1
  );

wfg_txck1_iom: NX_WFG_U
  generic map (
      mode        => 1
    , pattern_end => dataSize - 1
    -- , pattern_end => dataSizeTx - 1
    , pattern     => pattern
  )
  port map (
      ZI  => TXFCK1
    , ZO  => TXSCK1_IOM
    , SI  => SYNC1_IOM
    , SO  => SYNC1_IOM
  );

-- RXSCK1 generation for SPW RX logic in fabric
wfg_rxck1: NX_WFG_U
    generic map (
        mode        => 0
      , pattern_end => 0  --no divider, just use RXSC2 from CKO2
    )
    port map (
        ZI  => CKO1
      , ZO  => RXSCK1
      , SI  => SYNC1_RXSCK1
      , SO  => SYNC1_RXSCK1
    );

--SPW2 components#{{{#
RXEN2 <= NOT(RXRST2);
TXEN2 <= NOT(TXRST2);

iob_do2 : NX_IOB_O
    generic map (
        location     => bank & "_D13P"
      -- , standard     => "LVCMOS"
      -- , drive        => "4 mA"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
        I  => do2_i
      , C  => do2_c
      , IO => DO2
    );

iob_so2 : NX_IOB_O
    generic map (
        location     => bank & "_D14P"
      -- , standard     => "LVCMOS"
      -- , drive        => "4 mA"
      , standard     => "LVDS"
      , drive        => "Undefined"
      , differential => "True"
      , slewRate     => "Fast"
      , locked       => '1'
    )
    port map (
          I  => so2_i
        , C  => so2_c
        , IO => SO2
    );

iob_di2 : NX_IOB_I
    generic map (
        location             => bank & "_D15P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
          C  => di2_c
        , IO => DI2
        , O  => di2_o
    );

iob_si2 : NX_IOB_I
    generic map (
        location             => bank & "_D16P"
      , standard             => "LVDS"
      , drive                => "Undefined"
      , differential         => "True"
      , termination          => "50"
      , terminationReference => reference
      , turbo                => "True"
      , locked               => '1'
    )
    port map (
        C  => si2_c
      , IO => SI2
      , O  => si2_o
    );

iod_do2_p : NX_IOM_DRIVER_U
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , chained    => '1'
      , location   => bank & "_D13P"
      , symbol     => "DSO_DO2"
    )
    port map (
        CO   => do2_c
      , EO   => do2_i
      , EI1  => TXI2(0) --txi2_do(0)
      , EI2  => TXI2(1) --txi2_do(1)
      , EI3  => TXI2(2) --txi2_do(2)
      , EI4  => TXI2(3) --txi2_do(3)
      , EI5  => TXI2(4) --txi2_do(4)
      , EI6  => TXI2(5) --txi2_do(5)
      , EI7  => TXI2(6) --txi2_do(6)
      , EI8  => TXI2(7) --txi2_do(7)
      , ER   => TXEN2
      , LINK => do2_p_link
    );

iod_so2_p : NX_IOM_DRIVER_U
    generic map (
        epath_init => '1'
      , epath_load => '0'
      , epath_mode => b"0101" -- SPW
      , epath_sync => '0'
      , rpath_mode => b"0000" -- CST_0
      , cpath_mode => b"0001" -- OUTPUT
      , chained    => '1'
      , location   => bank & "_D14P"
      , symbol     => "DSO_SO2"
    )
    port map (
        CO   => so2_c
      , EO   => so2_i
      , EI1  => '1'
      , EI2  => '1'
      , EI3  => '1'
      , EI4  => '1'
      , EI5  => '1'
      , EI6  => '1'
      , EI7  => '1'
      , EI8  => '1'
      , ER   => TXEN2
      , LINK => so2_p_link
    );

iod_di2_p : NX_IOM_DRIVER_U
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , chained    => '1'
      , location   => bank & "_D15P"
      , symbol     => "DSI_DI2"
    )
    port map (
        CO   => di2_c
      , EO   => di2_i
      , RI   => di2_o
      , RO1  => RXO2(0) --rxi2_di(0)
      , RO2  => RXO2(2) --rxi2_di(1)
      , RO3  => RXO2(4) --rxi2_di(2)
      , RO4  => RXO2(6) --rxi2_di(3)
      , RO5  => RXO2(8) --rxi2_di(4)
      , RO6  => RXO2(10) --rxi2_di(5)
      , RO7  => RXO2(12) --rxi2_di(6)
      , RO8  => RXO2(14) --rxi2_di(7)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => di2_p_link
    );

iod_si2_p : NX_IOM_DRIVER_U
    generic map (
        rpath_init => '1'
      , rpath_load => '0'
      , rpath_mode => b"0101" -- SPW
      , rpath_sync => '0'
      , epath_mode => b"0000" -- CST_0
      , cpath_mode => b"0000" -- INPUT
      , chained    => '1'
      , location   => bank & "_D16P"
      , symbol     => "DSI_SI2"
    )
    port map (
        CO   => si2_c
      , EO   => si2_i
      , RI   => si2_o
      , RO1  => RXO2(1) --rxi2_si(0)
      , RO2  => RXO2(3) --rxi2_si(1)
      , RO3  => RXO2(5) --rxi2_si(2)
      , RO4  => RXO2(7) --rxi2_si(3)
      , RO5  => RXO2(9) --rxi2_si(4)
      , RO6  => RXO2(11) --rxi2_si(5)
      , RO7  => RXO2(13) --rxi2_si(6)
      , RO8  => RXO2(15) --rxi2_si(7)
      , RR   => RXRST2
      , ER   => RXEN2       -- enable SWRX
      , LINK => si2_p_link
    );

-- slow clock TXSCK2 generation for loadgen3
wfg_txck2: NX_WFG_U
    generic map (
        mode        => 1
      , pattern_end => dataSize - 1
      -- , pattern_end => dataSizeTx - 1
      , pattern     => pattern
    )
    port map (
        ZI  => TXFCK2
      , ZO  => TXSCK2
      , SI  => SYNC2
      , SO  => SYNC2
    );

wfg_txck2_iom: NX_WFG_U
    generic map (
        mode        => 1
      , pattern_end => dataSize - 1
      -- , pattern_end => dataSizeTx - 1
      , pattern     => pattern
    )
    port map (
        ZI  => TXFCK2
      , ZO  => TXSCK2_IOM
      , SI  => SYNC2_IOM
      , SO  => SYNC2_IOM
    );

-- RXSCK2 generation for SPW RX logic in fabric
wfg_rxck2: NX_WFG_U
    generic map (
        mode        => 0
      , pattern_end => 0  --no divider, just use RXSC2 from CKO2
    )
    port map (
        ZI  => CKO2
      , ZO  => RXSCK2
      , SI  => SYNC2_RXSCK2
      , SO  => SYNC2_RXSCK2
    );
-- #}}}#

--IOM_CONTROL#{{{#
ioc : NX_IOM_CONTROL_U
    generic map (
        mode_side1   => 2                 -- config SPW1 on PADS 1-8
      , div1         => TXDIV(dataSize)   -- config serial factor for SPWTX1
      -- , div1         => TXDIV(dataSizeTx) -- config serial factor for SPWTX1
      , mode_side3   => 2                 -- config SPW2 on PADS 27-34
      , div3         => TXDIV(dataSize)   -- config serial factor for SPWTX2
      -- , div3         => TXDIV(dataSizeTx) -- config serial factor for SPWTX2
   
      , div_swrx1    => RXDIV(dataSize)   -- config serial factor for SPWRX1
      , div_swrx2    => RXDIV(dataSize)   -- config serial factor for SPWRX2
      -- , div_swrx1    => RXDIV(dataSizeRx) -- config serial factor for SPWRX1
      -- , div_swrx2    => RXDIV(dataSizeRx) -- config serial factor for SPWRX2
   
      , sel_ld_fck1  => "01"              -- 0:None, 1:FCK1, 2:FCK2, 3:FDCK 
                                          -- select TXFCK1 fast clock on FCK1 input for loadgen1 internal block
      , sel_ld_fck3  => "10"              -- 0:None, 1:FCK1, 2:FCK2, 3:FDCK, TXFCK2 fast clock
                                          -- select TXFCK2 fast clock on FCK2 input for loadgen3 internal block
      , sel_sw_fck1  => "01"              -- select fast FCK1 clock for SPWTX1 internal block  
      , sel_sw_fck2  => "10"              -- select fast FCK2 clock for SPWTX2 internal block 
      
      , inv_ld_sck1  => '0'               -- 0: select LDSCK1, 1:select and invert LDSCK1 -> use TXSCK1_IOM slow clock for loadgen1
      , inv_ld_sck3  => '0'               -- 0: select LDSCK3, 1:select and invert LDSCK3 -> use TXSCK2_IOM slow clock for loadgen3

      , sel_clk_out1 => '1'               -- 0: CKO1 <= di[clk0] from clk pad only
                                          -- 1: CKO1 <= sw_rxclk2 generated by SWRX1
      , sel_clk_out2 => '1'               -- 0: CKO2 <= di[clk1] from clk pad only
                                          -- 1: CKO2 <= sw_rxclk2 generated by SWRX2
      , location     => bank
    )
    port map (
        LINK1   => do1_p_link
      , LINK3   => so1_p_link
      , LINK5   => di1_p_link
      , LINK7   => si1_p_link
      , LINK27  => do2_p_link
      , LINK29  => so2_p_link
      , LINK31  => di2_p_link
      , LINK33  => si2_p_link

      , LDSCK1  => TXSCK1_IOM   -- ldgen_ck_slow clock for loadgen1 internal block
      , LDSCK3  => TXSCK2_IOM   -- ldgen_ck_slow clock for loadgen3 internal block
      , LD1RN   => TXEN1        -- SPW1 TX Reset sent to loadgen1 inside IOM_CONTROL
      , LD3RN   => TXEN2        -- SPW2 TX Reset sent to loadgen3 inside IOM_CONTROL

      , FCK1    => TXFCK1	      -- ECK SPW1 fast clock for SPWTX1 internal block 
      , FCK2    => TXFCK2	      -- ECK SPW2 fast clock for SPWTX2 internal block

      , CKO1    => CKO1         -- XOR between DI & SI, RXCLK SPW1
      , CKO2    => CKO2         -- XOR between DI & SI, RXCLK SPW2
  );
--#}}}#

end NX_RTL;
--#}}}#



--------------------------------------------------------------------------------
-- Title        : SpaceWire PHY
-- Project      : SPW_PHY
--------------------------------------------------------------------------------
-- File         : spw_phy.vhd
-- Author       : Quentin Olivier 
-- Company      : NanoXplore
--------------------------------------------------------------------------------
-- Description  :
-- Wrapper of IP SpaceWire FIFO IOM for simulation and emulation
--------------------------------------------------------------------------------
-- Copyright (c) 2016
--------------------------------------------------------------------------------
-- Revisions    :
-- Date       Version Author        Description
-- 2023-02-18 1.0     qolivier      Created
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Library declaration                                                        --
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.math_real.all;

--------------------------------------------------------------------------------
-- Entity declaration                                                         --
--------------------------------------------------------------------------------
entity spw_phy is
  generic(
    dataSize            :     integer range 4 to 10 := 8;      -- data size can be 4, 6, 8 or 10 bits (Medium and Large FPGA) or 4, 6 or 8 bits (Ultra FPGA)
    bank                :     string                := "IOB23"; -- IO Bank name where the SPW interfaces are located
    G_FPGA_ARCH         :     natural               :=  0;
    reference           :     string                := "floating" -- termination reference, can be floating or VT
  );
  port (
    -- SpaceWire 1 parallel interface
    clk_spw1_ftx_i      : in  std_logic;                        -- Input  TX fast clock used by IOM
    clk_spw1_stx_o      : out std_logic;                        -- Output TX slow clock given by IOM
    rst_spw1_tx_i       : in  std_logic;
    spw1_tx_data_i      : in  std_logic_vector(dataSize -1 downto 0);
    
    rst_spw1_rx_i       : in  std_logic;
    spw1_rx_data_vld_o  : out std_logic;
    spw1_rx_data_o      : out std_logic_vector(2*dataSize-1 downto 0);

    -- SpaceWire 2 parallel interface
    clk_spw2_ftx_i      : in  std_logic;                        -- Input  TX fast clock used by IOM
    clk_spw2_stx_o      : out std_logic;                        -- Output TX slow clock given by IOM
    rst_spw2_tx_i       : in  std_logic;
    spw2_tx_data_i      : in  std_logic_vector(dataSize -1 downto 0);

    rst_spw2_rx_i       : in  std_logic;
    spw2_rx_data_vld_o  : out std_logic;
    spw2_rx_data_o      : out std_logic_vector(2*dataSize-1 downto 0);

    -- SpaceWire 1 serial link interface
    spw1_d_i            : in  std_logic;    -- data input
    spw1_s_i            : in  std_logic;    -- strobe input
    spw1_d_o            : out std_logic;    -- data output
    spw1_s_o            : out std_logic;    -- strobe output

    -- SpaceWire 2 serial link interface
    spw2_d_i            : in  std_logic;    -- data input
    spw2_s_i            : in  std_logic;    -- strobe input
    spw2_d_o            : out std_logic;    -- data output
    spw2_s_o            : out std_logic;    -- strobe output

    -- Other interface
    debug_port_o        : out std_logic_vector(63 downto 0)
  );
end entity;

architecture rtl of spw_phy is

--------------------------------------------------------------------------------
-- Component declaration                                                      --
--------------------------------------------------------------------------------
component IP_SPW_BANK_L is
  generic (
    dataSize    :     integer range 4 to 10 := 10;                        -- data size can be 4, 6, 8 or 10 bits
    bank        :     string  := "IOB12";                                 -- IO bank name
    reference   :     string  := "floating"                               -- termination reference, can be floating or VT
  );
  port (
    DO1       : out std_logic;                                          -- SPW1 D out
    SO1       : out std_logic;                                          -- SPW1 S out
    DI1       : in  std_logic := '0';                                   -- SPW1 D in
    SI1       : in  std_logic := '0';                                   -- SPW1 S in

    RXRST1    : in  std_logic := '0';                                   -- SPW1 RX reset
    RXO1      : out std_logic_vector(19 downto 0);                      -- SPW1 RX data out (2x10 bits)
    RXSCK1    : out std_logic;                                          -- SPW1 RX slow clock

    TXRST1    : in  std_logic := '0';                                   -- SPW1 TX reset
    TXI1      : in  std_logic_vector(9 downto 0) := (others => '0');    -- SPW1 TX data in (10 bits)
    TXFCK1    : in  std_logic := '0';                                   -- SPW1 TX fast clock
    TXSCK1    : out std_logic;                                          -- SPW1 TX slow clock

    DO2       : out std_logic;                                          -- SPW2 D out
    SO2       : out std_logic;                                          -- SPW2 S out
    DI2       : in  std_logic := '0';                                   -- SPW2 D in
    SI2       : in  std_logic := '0';                                   -- SPW2 S in

    RXRST2    : in  std_logic := '0';                                   -- SPW2 RX reset
    RXO2      : out std_logic_vector(19 downto 0);                      -- SPW2 RX data out (2x10 bits)
    RXSCK2    : out std_logic;                                          -- SPW2 RX slow clock

    TXRST2    : in  std_logic := '0';                                   -- SPW2 TX reset
    TXI2      : in  std_logic_vector(9 downto 0) := (others => '0');    -- SPW2 TX data in (10 bits)
    TXFCK2    : in  std_logic := '0';                                   -- SPW2 TX fast clock
    TXSCK2    : out std_logic                                           -- SPW2 TX slow clock
  );
end component;

component IP_SPW_BANK_M is
  generic (
    dataSize    :     integer range 4 to 10 := 10;                        -- data size can be 4, 6, 8 or 10 bits
    bank        :     string  := "IOB12";                                 -- IO bank name
    reference   :     string  := "floating"                               -- termination reference, can be floating or VT
  );
  port (
    DO1       : out std_logic;                                          -- SPW1 D out
    SO1       : out std_logic;                                          -- SPW1 S out
    DI1       : in  std_logic := '0';                                   -- SPW1 D in
    SI1       : in  std_logic := '0';                                   -- SPW1 S in

    RXRST1    : in  std_logic := '0';                                   -- SPW1 RX reset
    RXO1      : out std_logic_vector(19 downto 0);                      -- SPW1 RX data out (2x10 bits)
    RXSCK1    : out std_logic;                                          -- SPW1 RX slow clock

    TXRST1    : in  std_logic := '0';                                   -- SPW1 TX reset
    TXI1      : in  std_logic_vector(9 downto 0) := (others => '0');    -- SPW1 TX data in (10 bits)
    TXFCK1    : in  std_logic := '0';                                   -- SPW1 TX fast clock
    TXSCK1    : out std_logic;                                          -- SPW1 TX slow clock

    DO2       : out std_logic;                                          -- SPW2 D out
    SO2       : out std_logic;                                          -- SPW2 S out
    DI2       : in  std_logic := '0';                                   -- SPW2 D in
    SI2       : in  std_logic := '0';                                   -- SPW2 S in

    RXRST2    : in  std_logic := '0';                                   -- SPW2 RX reset
    RXO2      : out std_logic_vector(19 downto 0);                      -- SPW2 RX data out (2x10 bits)
    RXSCK2    : out std_logic;                                          -- SPW2 RX slow clock

    TXRST2    : in  std_logic := '0';                                   -- SPW2 TX reset
    TXI2      : in  std_logic_vector(9 downto 0) := (others => '0');    -- SPW2 TX data in (10 bits)
    TXFCK2    : in  std_logic := '0';                                   -- SPW2 TX fast clock
    TXSCK2    : out std_logic                                           -- SPW2 TX slow clock
  );
end component;

component IP_SPW_BANK_U is
  generic (
    dataSize    : integer range 4 to 8 := 8;        -- data size can be 4, 6, 8
    bank        : string  := "IOB23";               -- IO bank name
    reference   : string  := "floating"             -- termination reference, can be floating or VT
  );
  port (
    DO1    : out std_logic;                                         -- SPW1 D out
    SO1    : out std_logic;                                         -- SPW1 S out
    DI1    : in  std_logic := '0';                                  -- SPW1 D in
    SI1    : in  std_logic := '0';                                  -- SPW1 S in

    RXRST1 : in  std_logic := '0';                                  -- SPW1 RX reset
    RXO1   : out std_logic_vector(15 downto 0);                     -- SPW1 RX data out (2x8 bits)
    RXSCK1 : out std_logic;                                         -- SPW1 RX slow clock

    TXRST1 : in  std_logic := '0';                                  -- SPW1 TX reset
    TXI1   : in  std_logic_vector(7 downto 0) := (others => '0');   -- SPW1 TX data in (8 bits)
    TXFCK1 : in  std_logic := '0';                                  -- SPW1 TX fast clock
    TXSCK1 : out std_logic;                                         -- SPW1 TX slow clock

    DO2    : out std_logic;                                         -- SPW2 D out
    SO2    : out std_logic;                                         -- SPW2 S out
    DI2    : in  std_logic := '0';                                  -- SPW2 D in
    SI2    : in  std_logic := '0';                                  -- SPW2 S in

    RXRST2 : in  std_logic := '0';                                  -- SPW2 RX reset
    RXO2   : out std_logic_vector(15 downto 0);                     -- SPW2 RX data out (2x8 bits)
    RXSCK2  : out std_logic;                                         -- SPW2 RX slow clock

    TXRST2 : in  std_logic := '0';                                  -- SPW2 TX reset
    TXI2   : in  std_logic_vector(7 downto 0) := (others => '0');   -- SPW2 TX data in (8 bits)
    TXFCK2 : in  std_logic := '0';                                  -- SPW2 TX fast clock
    TXSCK2 : out std_logic                                          -- SPW2 TX slow clock
  );
end component IP_SPW_BANK_U;


--------------------------------------------------------------------------------
-- Signal declaration                                                         --
--------------------------------------------------------------------------------
  -- SPACEWIRE_CORE 1
signal    spw1_tx_data                : std_logic_vector( 9 downto 0);
signal    spw1_tx_data_u              : std_logic_vector( 7 downto 0);

signal    spw1_rx_data                : std_logic_vector(19 downto 0);
signal    spw1_rx_data_u              : std_logic_vector(15 downto 0);

signal    spw1_tx_sclk                : std_logic;
signal    spw1_rx_sclk                : std_logic;

-- SPACEWIRE_CORE 2
signal    spw2_tx_data                : std_logic_vector( 9 downto 0);
signal    spw2_tx_data_u              : std_logic_vector( 7 downto 0);

signal    spw2_rx_data                : std_logic_vector(19 downto 0);
signal    spw2_rx_data_u              : std_logic_vector(15 downto 0);

signal    spw2_tx_sclk                : std_logic;
signal    spw2_rx_sclk                : std_logic;

--------------------------------------------------------------------------------
-- RTL                                                                        --
--------------------------------------------------------------------------------
begin

--------------------------------------------------------------------------
----------------------------- NG_MEDIUM ----------------------------------
--------------------------------------------------------------------------
  gen_ng_medium_spw_bank : if G_FPGA_ARCH = 0 generate

    -- Unused signals
    spw1_tx_data_u  <=  (others => '0');
    spw2_tx_data_u  <=  (others => '0');

    spw1_rx_data_u  <=  (others => '0');
    spw2_rx_data_u  <=  (others => '0');

    spw1_tx_data    <=  "000000"  & spw1_tx_data_i(3 downto 0) when dataSize = 4 else
                        "00000"   & spw1_tx_data_i(4 downto 0) when dataSize = 5 else
                        "0000"    & spw1_tx_data_i(5 downto 0) when dataSize = 6 else
                        "000"     & spw1_tx_data_i(6 downto 0) when dataSize = 7 else
                        "00"      & spw1_tx_data_i(7 downto 0) when dataSize = 8 else
                        "0"       & spw1_tx_data_i(8 downto 0) when dataSize = 9 else
                                    spw1_tx_data_i;
  
    spw2_tx_data    <=  "000000"  & spw2_tx_data_i(3 downto 0) when dataSize = 4 else
                        "00000"   & spw2_tx_data_i(4 downto 0) when dataSize = 5 else
                        "0000"    & spw2_tx_data_i(5 downto 0) when dataSize = 6 else
                        "000"     & spw2_tx_data_i(6 downto 0) when dataSize = 7 else
                        "00"      & spw2_tx_data_i(7 downto 0) when dataSize = 8 else
                        "0"       & spw2_tx_data_i(8 downto 0) when dataSize = 9 else
                                    spw2_tx_data_i;
    
    ins_ip_spw_bank : IP_SPW_BANK_M
    generic map (
      dataSize      =>  dataSize,
      bank            =>  bank,
      reference       =>  reference
    )
    port map (
      DO1             =>  spw1_d_o,           -- SPW1 D out
      SO1             =>  spw1_s_o,           -- SPW1 S out
      DI1             =>  spw1_d_i,           -- SPW1 D in
      SI1             =>  spw1_s_i,           -- SPW1 S in

      RXRST1          =>  rst_spw1_rx_i,      -- SPW1 RX reset
      RXO1            =>  spw1_rx_data,       -- SPW1 RX data out (2x10 bits)
      RXSCK1          =>  spw1_rx_sclk,       -- SPW1 RX slow clock

      TXRST1          =>  rst_spw1_tx_i,      -- SPW1 TX reset
      TXI1            =>  spw1_tx_data,       -- SPW1 TX data in (10 bits)
      TXFCK1          =>  clk_spw1_ftx_i,     -- SPW1 TX fast clock
      TXSCK1          =>  spw1_tx_sclk,       -- SPW1 TX slow clock

      -----------------------------------------------------------------

      DO2             =>  spw2_d_o,           -- SPW2 D out
      SO2             =>  spw2_s_o,           -- SPW2 S out
      DI2             =>  spw2_d_i,           -- SPW2 D in
      SI2             =>  spw2_s_i,           -- SPW2 S in

      RXRST2          =>  rst_spw2_rx_i,      -- SPW2 RX reset
      RXO2            =>  spw2_rx_data,       -- SPW2 RX data out (2x10 bits)
      RXSCK2          =>  spw2_rx_sclk,       -- SPW2 RX slow clock

      TXRST2          =>  rst_spw2_tx_i,      -- SPW2 TX reset
      TXI2            =>  spw2_tx_data,       -- SPW2 TX data in (10 bits)
      TXFCK2          =>  clk_spw2_ftx_i,     -- SPW2 TX fast clock
      TXSCK2          =>  spw2_tx_sclk        -- SPW2 TX slow clock
    );

    spw1_rx_data_vld_o    <=  spw1_rx_sclk;
    spw2_rx_data_vld_o    <=  spw2_rx_sclk;
  end generate;

--------------------------------------------------------------------------
----------------------------- NG_LARGE -----------------------------------
--------------------------------------------------------------------------
  gen_ng_large_spw_bank : if G_FPGA_ARCH = 1 generate

    -- Unused signals
    spw1_tx_data_u  <=  (others => '0');
    spw2_tx_data_u  <=  (others => '0');

    spw1_rx_data_u  <=  (others => '0');
    spw2_rx_data_u  <=  (others => '0');

    spw1_tx_data    <=  "000000"  & spw1_tx_data_i(3 downto 0) when dataSize = 4 else
                        "00000"   & spw1_tx_data_i(4 downto 0) when dataSize = 5 else
                        "0000"    & spw1_tx_data_i(5 downto 0) when dataSize = 6 else
                        "000"     & spw1_tx_data_i(6 downto 0) when dataSize = 7 else
                        "00"      & spw1_tx_data_i(7 downto 0) when dataSize = 8 else
                        "0"       & spw1_tx_data_i(8 downto 0) when dataSize = 9 else
                                    spw1_tx_data_i;
  
    spw2_tx_data    <=  "000000"  & spw2_tx_data_i(3 downto 0) when dataSize = 4 else
                        "00000"   & spw2_tx_data_i(4 downto 0) when dataSize = 5 else
                        "0000"    & spw2_tx_data_i(5 downto 0) when dataSize = 6 else
                        "000"     & spw2_tx_data_i(6 downto 0) when dataSize = 7 else
                        "00"      & spw2_tx_data_i(7 downto 0) when dataSize = 8 else
                        "0"       & spw2_tx_data_i(8 downto 0) when dataSize = 9 else
                                    spw2_tx_data_i;
    
    ins_ip_spw_bank : IP_SPW_BANK_L
    generic map (
      dataSize        =>  dataSize,
      bank            =>  bank,
      reference       =>  reference
    )
    port map (
      DO1             =>  spw1_d_o,           -- SPW1 D out
      SO1             =>  spw1_s_o,           -- SPW1 S out
      DI1             =>  spw1_d_i,           -- SPW1 D in
      SI1             =>  spw1_s_i,           -- SPW1 S in

      RXRST1          =>  rst_spw1_rx_i,      -- SPW1 RX reset
      RXO1            =>  spw1_rx_data,       -- SPW1 RX data out (2x10 bits)
      RXSCK1          =>  spw1_rx_sclk,       -- SPW1 RX slow clock

      TXRST1          =>  rst_spw1_tx_i,      -- SPW1 TX reset
      TXI1            =>  spw1_tx_data,       -- SPW1 TX data in (10 bits)
      TXFCK1          =>  clk_spw1_ftx_i,     -- SPW1 TX fast clock
      TXSCK1          =>  spw1_tx_sclk,       -- SPW1 TX slow clock

      -----------------------------------------------------------------

      DO2             =>  spw2_d_o,           -- SPW2 D out
      SO2             =>  spw2_s_o,           -- SPW2 S out
      DI2             =>  spw2_d_i,           -- SPW2 D in
      SI2             =>  spw2_s_i,           -- SPW2 S in

      RXRST2          =>  rst_spw2_rx_i,      -- SPW2 RX reset
      RXO2            =>  spw2_rx_data,       -- SPW2 RX data out (2x10 bits)
      RXSCK2          =>  spw2_rx_sclk,       -- SPW2 RX slow clock

      TXRST2          =>  rst_spw2_tx_i,      -- SPW2 TX reset
      TXI2            =>  spw2_tx_data,       -- SPW2 TX data in (10 bits)
      TXFCK2          =>  clk_spw2_ftx_i,     -- SPW2 TX fast clock
      TXSCK2          =>  spw2_tx_sclk        -- SPW2 TX slow clock
    );

    spw1_rx_data_vld_o      <=  spw1_rx_sclk;
    spw2_rx_data_vld_o      <=  spw2_rx_sclk;
  end generate;

--------------------------------------------------------------------------
----------------------------- NG_ULTRA -----------------------------------
--------------------------------------------------------------------------
  gen_ng_ultra_spw_bank : if G_FPGA_ARCH = 2 generate
    spw_data_in_reverse : for i in 0 to dataSize-1 generate
      spw1_tx_data_u(7-i)   <=  spw1_tx_data_i(i);
      spw2_tx_data_u(7-i)   <=  spw2_tx_data_i(i);
    end generate;

    spw_data_in_blank : if dataSize < 8 generate
      spw1_tx_data_u(dataSize-1 downto 0)   <=  (others => '0');
      spw2_tx_data_u(dataSize-1 downto 0)   <=  (others => '0');
    end generate;

    spw1_tx_data            <=  "00" & spw1_tx_data_u;
    spw2_tx_data            <=  "00" & spw2_tx_data_u;
    
    ins_ip_spw_bank : IP_SPW_BANK_U
    generic map (
      dataSize        =>  dataSize,
      bank            =>  bank,
      reference       =>  reference
    )
    port map (
      DO1             =>  spw1_d_o,           -- SPW1 D out
      SO1             =>  spw1_s_o,           -- SPW1 S out
      DI1             =>  spw1_d_i,           -- SPW1 D in
      SI1             =>  spw1_s_i,           -- SPW1 S in

      RXRST1          =>  rst_spw1_rx_i,      -- SPW1 RX reset
      RXO1            =>  spw1_rx_data_u,     -- SPW1 RX data out (2x10 bits)
      RXSCK1          =>  spw1_rx_sclk,       -- SPW1 RX slow clock

      TXRST1          =>  rst_spw1_tx_i,      -- SPW1 TX reset
      TXI1            =>  spw1_tx_data_u,     -- SPW1 TX data in (10 bits)
      TXFCK1          =>  clk_spw1_ftx_i,     -- SPW1 TX fast clock
      TXSCK1          =>  spw1_tx_sclk,       -- SPW1 TX slow clock

      -----------------------------------------------------------------

      DO2             =>  spw2_d_o,           -- SPW2 D out
      SO2             =>  spw2_s_o,           -- SPW2 S out
      DI2             =>  spw2_d_i,           -- SPW2 D in
      SI2             =>  spw2_s_i,           -- SPW2 S in

      RXRST2          =>  rst_spw2_rx_i,      -- SPW2 RX reset
      RXO2            =>  spw2_rx_data_u,     -- SPW2 RX data out (2x10 bits)
      RXSCK2          =>  spw2_rx_sclk,       -- SPW2 RX slow clock

      TXRST2          =>  rst_spw2_tx_i,      -- SPW2 TX reset
      TXI2            =>  spw2_tx_data_u,     -- SPW2 TX data in (10 bits)
      TXFCK2          =>  clk_spw2_ftx_i,     -- SPW2 TX fast clock
      TXSCK2          =>  spw2_tx_sclk        -- SPW2 TX slow clock
    );

    spw_data_out_reverse : for i in 0 to 2*dataSize-1 generate
      spw1_rx_data(15-i)    <=  spw1_rx_data_u(i);
      spw2_rx_data(15-i)    <=  spw2_rx_data_u(i);
    end generate;

    spw_data_out_blank : if dataSize < 8 generate
      spw1_rx_data(dataSize-1 downto 0) <=  (others => '0');
      spw2_rx_data(dataSize-1 downto 0) <=  (others => '0');
    end generate;
    
    spw1_rx_data(19 downto 16)  <=  (others => '0');
    spw2_rx_data(19 downto 16)  <=  (others => '0');

    spw1_rx_data_vld_o          <=  not spw1_rx_sclk;
    spw2_rx_data_vld_o          <=  not spw2_rx_sclk;

  end generate;

  clk_spw1_stx_o              <=  spw1_tx_sclk;
  clk_spw2_stx_o              <=  spw2_tx_sclk;

  spw1_rx_data_o              <=  spw1_rx_data(2*dataSize-1 downto 0);
  spw2_rx_data_o              <=  spw2_rx_data(2*dataSize-1 downto 0);

  debug_port_o( 9 downto  0)  <=  spw1_tx_data;
  debug_port_o(10)            <=  spw1_tx_sclk;

  debug_port_o(30 downto 11)  <=  spw1_rx_data;
  debug_port_o(31)            <=  not spw1_rx_sclk;

  debug_port_o(41 downto 32)  <=  spw2_tx_data;
  debug_port_o(42)            <=  spw2_tx_sclk;

  debug_port_o(62 downto 43)  <=  spw2_rx_data;
  debug_port_o(63)            <=  not spw2_rx_sclk;


end rtl;
