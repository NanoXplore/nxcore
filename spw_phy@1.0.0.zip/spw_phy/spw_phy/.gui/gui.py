# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'gui.ui'
##
## Created by: Qt User Interface Compiler version 6.9.3
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QGridLayout, QLabel,
    QLayout, QSizePolicy, QSpacerItem, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        self.gridLayout = QGridLayout(Form)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.dataSizeLabel = QLabel(Form)
        self.dataSizeLabel.setObjectName(u"dataSizeLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.dataSizeLabel.sizePolicy().hasHeightForWidth())
        self.dataSizeLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.dataSizeLabel, 0, 0, 1, 1)

        self.dataSize = QComboBox(Form)
        self.dataSize.addItem("")
        self.dataSize.addItem("")
        self.dataSize.addItem("")
        self.dataSize.addItem("")
        self.dataSize.setObjectName(u"dataSize")
        sizePolicy1.setHeightForWidth(self.dataSize.sizePolicy().hasHeightForWidth())
        self.dataSize.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.dataSize, 0, 1, 1, 1)

        self.BANKLabel = QLabel(Form)
        self.BANKLabel.setObjectName(u"BANKLabel")
        sizePolicy1.setHeightForWidth(self.BANKLabel.sizePolicy().hasHeightForWidth())
        self.BANKLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.BANKLabel, 1, 0, 1, 1)

        self.BANK = QComboBox(Form)
        self.BANK.addItem("")
        self.BANK.addItem("")
        self.BANK.addItem("")
        self.BANK.addItem("")
        self.BANK.addItem("")
        self.BANK.addItem("")
        self.BANK.addItem("")
        self.BANK.addItem("")
        self.BANK.setObjectName(u"BANK")
        sizePolicy1.setHeightForWidth(self.BANK.sizePolicy().hasHeightForWidth())
        self.BANK.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.BANK, 1, 1, 1, 1)

        self.G_FPAGA_ARCHLabel = QLabel(Form)
        self.G_FPAGA_ARCHLabel.setObjectName(u"G_FPAGA_ARCHLabel")
        sizePolicy1.setHeightForWidth(self.G_FPAGA_ARCHLabel.sizePolicy().hasHeightForWidth())
        self.G_FPAGA_ARCHLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.G_FPAGA_ARCHLabel, 2, 0, 1, 1)

        self.G_FPAGA_ARCH = QComboBox(Form)
        self.G_FPAGA_ARCH.addItem("")
        self.G_FPAGA_ARCH.addItem("")
        self.G_FPAGA_ARCH.setObjectName(u"G_FPAGA_ARCH")
        sizePolicy1.setHeightForWidth(self.G_FPAGA_ARCH.sizePolicy().hasHeightForWidth())
        self.G_FPAGA_ARCH.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.G_FPAGA_ARCH, 2, 1, 1, 1)

        self.referenceLabel = QLabel(Form)
        self.referenceLabel.setObjectName(u"referenceLabel")
        sizePolicy1.setHeightForWidth(self.referenceLabel.sizePolicy().hasHeightForWidth())
        self.referenceLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.referenceLabel, 3, 0, 1, 1)

        self.reference = QComboBox(Form)
        self.reference.addItem("")
        self.reference.addItem("")
        self.reference.setObjectName(u"reference")
        sizePolicy1.setHeightForWidth(self.reference.sizePolicy().hasHeightForWidth())
        self.reference.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.reference, 3, 1, 1, 1)

        self.verticalSpacer = QSpacerItem(0, 0, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout.addItem(self.verticalSpacer, 4, 0, 1, 2)


        self.retranslateUi(Form)

        self.dataSize.setCurrentIndex(2)
        self.BANK.setCurrentIndex(1)
        self.G_FPAGA_ARCH.setCurrentIndex(0)
        self.reference.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Auto-generated UI", None))
#if QT_CONFIG(tooltip)
        self.dataSizeLabel.setToolTip(QCoreApplication.translate("Form", u"Data width parameter", None))
#endif // QT_CONFIG(tooltip)
        self.dataSizeLabel.setText(QCoreApplication.translate("Form", u"dataSize", None))
        self.dataSize.setItemText(0, QCoreApplication.translate("Form", u"4", None))
        self.dataSize.setItemText(1, QCoreApplication.translate("Form", u"6", None))
        self.dataSize.setItemText(2, QCoreApplication.translate("Form", u"8", None))
        self.dataSize.setItemText(3, QCoreApplication.translate("Form", u"10", None))

#if QT_CONFIG(tooltip)
        self.BANKLabel.setToolTip(QCoreApplication.translate("Form", u"Bank Selection (location)", None))
#endif // QT_CONFIG(tooltip)
        self.BANKLabel.setText(QCoreApplication.translate("Form", u"BANK", None))
        self.BANK.setItemText(0, QCoreApplication.translate("Form", u"IOB02", None))
        self.BANK.setItemText(1, QCoreApplication.translate("Form", u"IOB03", None))
        self.BANK.setItemText(2, QCoreApplication.translate("Form", u"IOB04", None))
        self.BANK.setItemText(3, QCoreApplication.translate("Form", u"IOB05", None))
        self.BANK.setItemText(4, QCoreApplication.translate("Form", u"IOB09", None))
        self.BANK.setItemText(5, QCoreApplication.translate("Form", u"IOB10", None))
        self.BANK.setItemText(6, QCoreApplication.translate("Form", u"IOB11", None))
        self.BANK.setItemText(7, QCoreApplication.translate("Form", u"IOB12", None))

#if QT_CONFIG(tooltip)
        self.G_FPAGA_ARCHLabel.setToolTip(QCoreApplication.translate("Form", u"FPGA target (0 = Medium / 2 = Ultra or U300)", None))
#endif // QT_CONFIG(tooltip)
        self.G_FPAGA_ARCHLabel.setText(QCoreApplication.translate("Form", u"G_FPAGA_ARCH", None))
        self.G_FPAGA_ARCH.setItemText(0, QCoreApplication.translate("Form", u"0", None))
        self.G_FPAGA_ARCH.setItemText(1, QCoreApplication.translate("Form", u"2", None))

#if QT_CONFIG(tooltip)
        self.referenceLabel.setToolTip(QCoreApplication.translate("Form", u"termination reference", None))
#endif // QT_CONFIG(tooltip)
        self.referenceLabel.setText(QCoreApplication.translate("Form", u"reference", None))
        self.reference.setItemText(0, QCoreApplication.translate("Form", u"floating", None))
        self.reference.setItemText(1, QCoreApplication.translate("Form", u"vt", None))

    # retranslateUi

