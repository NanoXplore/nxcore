
from nxcorelib import (
    Metadata, Param, Port,            # dataclass to define constants METADATA, PARAMS, PORTS, FILES
    ParamType,                              # parameter type
    ComboBox,                                # parameter widget 
    depends_on, Helper                      # access to internal data model 
)

from enum import Enum   # useful to define groups


#------------------------------
# Custom validators
#------------------------------


#------------------------------
# Custom updaters
#------------------------------

def set_items(param_name,iob_medium,iob_ultra,iob_u300):
   @depends_on()
   def updater():
       current_value = Helper.Value()
    #    v = Helper.Value(param_name)
    #    if current_value == 0:
    #        Helper.UI.Set_items(param_name,iob_medium, v)
    #    elif  current_value == 2:
    #        Helper.UI.Set_items(param_name,iob_ultra, v)
    #    elif  current_value == 3:
    #        Helper.UI.Set_items(param_name,iob_u300, v)

       if current_value == 0:
           Helper.UI.Set_items(param_name,iob_medium)
       elif  current_value == 2:
           Helper.UI.Set_items(param_name,iob_ultra)
       elif  current_value == 3:
           Helper.UI.Set_items(param_name,iob_u300)
   return updater


#------------------------------
# Model
#------------------------------
# Metadata of the IP
METADATA = Metadata(
    top="spw_phy",
    name = "spw_phy",
    description = "spw_phy IP",
    version = "1.0.0",
    release = "2026/07/06",
    variants = ["NG-MEDIUM", "NG-ULTRA", "ULTRA300"],
    vendor = "NX",
    library = "Interface"
)

# define your parameters here. Each parameter in an instance of Param. 
PARAMS = [             
        Param(
            name="dataSize",
            description="Data width parameter" , 
            group=None, 
            type=ParamType.NATURAL,
            widget = ComboBox([4 , 6 , 8 , 10]),
            value=8, 
            validators=[],
            updaters = []
        ),

        Param(
            name="BANK",
            description="Bank Selection (location)" , 
            group=None, 
            type=ParamType.STRING,
            widget = ComboBox(["IOB02", "IOB03", "IOB04", "IOB05", "IOB09", "IOB10", "IOB11" , "IOB12"]),
            value="IOB03", 
            validators=[],
            updaters = []
        ),

        Param(
           name="G_FPAGA_ARCH",
           description="FPGA target (0 = Medium / 2 = Ultra or U300)" , 
           group=None, 
           type=ParamType.NATURAL,
           widget = ComboBox([0 , 2]),
           value=0, 
           validators=[],
           updaters = #[]
           [set_items("BANK",["IOB02", "IOB03", "IOB04", "IOB05", "IOB09", "IOB10", "IOB11" , "IOB12"],
                            ["IOB02", "IOB03", "IOB04", "IOB05", "IOB08", "IOB09", "IOB10", "IOB11", "IOB12" , "IOB13"],
                            ["IOB03", "IOB04", "IOB05", "IOB06", "IOB09", "IOB10", "IOB11", "IOB15", "IOB16" , "IOB17"]),
            set_items("dataSize",[4 , 6 , 8 , 10],[4 , 6 , 8],[4 , 6 , 8])]
        ),

        Param(
            name="reference",
            description="termination reference" , 
            group=None, 
            type=ParamType.STRING,
            widget = ComboBox(["floating","vt"]),
            value="vt", 
            validators=[],
            updaters = []
        )
]

# define your ports here. Each port in an instance of Port. 
PORTS = [
        Port(
            group = "SPW1",
            name = "clk_spw1_ftx_i",
            description = "Fast clk",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "clk_spw1_stx_o",
            description = "Slow clk",
            type = "std_logic",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "rst_spw1_tx_i",
            description = "Reset tx",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "spw1_tx_data_i",
            description = "TX data input",
            type = "std_logic_vector(dataSize -1 downto 0)",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "rst_spw1_rx_i",
            description = "Reset RX",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "spw1_rx_data_vld_o",
            description = "Valid RX data output",
            type = "std_logic",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "spw1_rx_data_o",
            description = "Data output",
            type = "std_logic_vector(2*dataSize-1 downto 0)",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "clk_spw2_ftx_i",
            description = "Fast Clock",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "clk_spw2_stx_o",
            description = "Slow Clock",
            type = "std_logic",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "rst_spw2_tx_i",
            description = "Reset TX",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "spw2_tx_data_i",
            description = "Data input",
            type = "std_logic_vector(dataSize-1 downto 0)",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "rst_spw2_rx_i",
            description = "Reset RX",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "spw2_rx_data_vld_o",
            description = "Valid data output",
            type = "std_logic",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "spw2_rx_data_o",
            description = "Data output",
            type = "std_logic_vector(2*dataSize-1 downto 0)",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "spw1_d_i",
            description = "Serial data input",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "spw1_s_i",
            description = "Serial strobe input",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "spw1_d_o",
            description = "Serial data output",
            type = "std_logic",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW1",
            name = "spw1_s_o",
            description = "Serial strobe output",
            type = "std_logic",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "spw2_d_i",
            description = "Serial data input",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "spw2_s_i",
            description = "Serial strobe input",
            type = "std_logic",
            direction = "in",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "spw2_d_o",
            description = "Serial data output",
            type = "std_logic",
            direction = "out",
            pragmas = None
        ),
        Port(
            group = "SPW2",
            name = "spw2_s_o",
            description = "Serial strobe output",
            type = "std_logic",
            direction = "out",
            pragmas = None
        )
]
